package com.espelho.tv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Display
import androidx.core.content.IntentCompat
import org.json.JSONObject
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.DataChannel
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpParameters
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object Status {
    @Volatile var text: String = ""
    @Volatile var running: Boolean = false
    @Volatile var listener: (() -> Unit)? = null
    fun set(t: String, run: Boolean) {
        text = t
        running = run
        listener?.invoke()
    }
}

open class SdpAdapter : SdpObserver {
    override fun onCreateSuccess(d: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(e: String?) {}
    override fun onSetFailure(e: String?) {}
}

class MirrorService : Service() {
    private val exec: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var source: VideoSource? = null
    private var track: VideoTrack? = null
    private var helper: SurfaceTextureHelper? = null
    private var capturer: ScreenCapturerAndroid? = null
    private var pc: PeerConnection? = null
    private var signaling: Signaling? = null

    @Volatile private var sid = ""
    @Volatile private var started = false
    private var firstOpen = true
    private var lastReady = ""
    private var retries = 0
    private val stopped = AtomicBoolean(false)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            shutdown()
            return START_NOT_STICKY
        }
        goForeground()
        val code = intent?.getStringExtra("code")
        val data = if (intent != null) IntentCompat.getParcelableExtra(intent, "data", Intent::class.java) else null
        if (code == null || data == null || started) {
            if (!started) stopSelf()
            return START_NOT_STICKY
        }
        started = true
        Status.set("Iniciando…", true)
        exec.execute {
            try {
                begin(code, data)
            } catch (e: Exception) {
                Status.set("Erro: " + e.message, false)
                shutdown()
            }
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("mirror", "Espelhamento", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, MirrorService::class.java).setAction("stop"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat), "Parar", stop
        ).build()
        val n = Notification.Builder(this, "mirror")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Espelhando na TV")
            .setContentText("Toque para abrir")
            .setContentIntent(open)
            .addAction(action)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun captureSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        val d = (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        d.getRealMetrics(dm)
        val big = max(dm.widthPixels, dm.heightPixels).toFloat()
        val k = min(1f, Config.MAX_LONG_SIDE / big)
        fun r(v: Int): Int = max(16, ((v * k) / 16f).roundToInt() * 16)
        return Pair(r(dm.widthPixels), r(dm.heightPixels))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        try {
            val (w, h) = captureSize()
            capturer?.changeCaptureFormat(w, h, Config.FPS)
        } catch (e: Exception) { }
    }

    private fun begin(code: String, data: Intent) {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val e = EglBase.create()
        egl = e
        val f = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(e.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(e.eglBaseContext))
            .createPeerConnectionFactory()
        factory = f
        val src = f.createVideoSource(false)
        source = src
        val h = SurfaceTextureHelper.create("cap", e.eglBaseContext)
        helper = h
        val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
            override fun onStop() { shutdown() }
        })
        capturer = cap
        cap.initialize(h, applicationContext, src.capturerObserver)
        val (w, hh) = captureSize()
        cap.startCapture(w, hh, Config.FPS)
        track = f.createVideoTrack("screen", src)

        val s = Signaling(
            code,
            onOpen = {
                exec.execute {
                    if (firstOpen) {
                        firstOpen = false
                        Status.set("Procurando a TV…", true)
                        negotiate()
                    }
                }
            },
            onMessage = { m -> exec.execute { onSignal(m) } }
        )
        signaling = s
        s.start()
    }

    private fun onSignal(m: JSONObject) {
        when (m.optString("t")) {
            "ready" -> {
                val rid = m.optString("rid")
                if (rid != lastReady) {
                    lastReady = rid
                    negotiate()
                }
            }
            "answer" -> {
                if (m.optString("sid") == sid) {
                    pc?.setRemoteDescription(
                        SdpAdapter(),
                        SessionDescription(SessionDescription.Type.ANSWER, m.getString("sdp"))
                    )
                    Status.set("Conectando…", true)
                }
            }
        }
    }

    private fun negotiate() {
        val f = factory ?: return
        val t = track ?: return
        closePc()
        val mySid = java.lang.Long.toString(System.currentTimeMillis(), 36)
        sid = mySid
        val sent = AtomicBoolean(false)

        fun sendOffer() {
            exec.execute {
                val p = pc ?: return@execute
                if (sid != mySid || !sent.compareAndSet(false, true)) return@execute
                val d = p.localDescription ?: return@execute
                signaling?.send(
                    JSONObject().put("from", "p").put("t", "offer")
                        .put("sid", mySid).put("sdp", d.description)
                )
            }
        }

        val ice = ArrayList<PeerConnection.IceServer>()
        for (u in Config.STUN) ice.add(PeerConnection.IceServer.builder(u).createIceServer())
        if (Config.TURN_URL.isNotEmpty()) {
            ice.add(
                PeerConnection.IceServer.builder(Config.TURN_URL)
                    .setUsername(Config.TURN_USER).setPassword(Config.TURN_PASS).createIceServer()
            )
        }
        val rtc = PeerConnection.RTCConfiguration(ice)
        rtc.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN

        val obs = object : PeerConnection.Observer {
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                when (s) {
                    PeerConnection.IceConnectionState.CONNECTED,
                    PeerConnection.IceConnectionState.COMPLETED -> {
                        retries = 0
                        Status.set("Espelhando na TV ✓", true)
                    }
                    PeerConnection.IceConnectionState.DISCONNECTED ->
                        Status.set("Conexão instável…", true)
                    PeerConnection.IceConnectionState.FAILED -> {
                        if (retries < 3) {
                            retries++
                            Status.set("Falhou. Tentando de novo…", true)
                            exec.schedule(Runnable { if (sid == mySid) negotiate() }, 2, TimeUnit.SECONDS)
                        } else {
                            Status.set("Não conectou. A rede pode bloquear; configure um TURN (veja LEIA-ME).", true)
                        }
                    }
                    else -> {}
                }
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {
                if (s == PeerConnection.IceGatheringState.COMPLETE) sendOffer()
            }
            override fun onIceCandidate(c: IceCandidate?) {}
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(d: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
        }

        val p = f.createPeerConnection(rtc, obs)
        if (p == null) {
            Status.set("Erro ao criar a conexão", true)
            return
        }
        pc = p
        p.addTrack(t, listOf("s"))
        tune(p)
        p.createOffer(object : SdpAdapter() {
            override fun onCreateSuccess(d: SessionDescription?) {
                if (d == null) return
                val m = SessionDescription(d.type, preferH264(d.description))
                p.setLocalDescription(object : SdpAdapter() {
                    override fun onSetFailure(e: String?) {
                        Status.set("Erro SDP: $e", true)
                    }
                }, m)
                exec.schedule(Runnable { sendOffer() }, 2500, TimeUnit.MILLISECONDS)
            }
        }, MediaConstraints())
    }

    // Prioriza H.264 (codificador de hardware do celular = menos atraso e menos calor)
    private fun preferH264(sdp: String): String {
        val lines = sdp.split("\r\n").toMutableList()
        val mIdx = lines.indexOfFirst { it.startsWith("m=video") }
        if (mIdx < 0) return sdp
        val h264 = lines.filter { it.startsWith("a=rtpmap:") && it.contains("H264/90000") }
            .map { it.substringAfter("a=rtpmap:").substringBefore(" ") }
        if (h264.isEmpty()) return sdp
        val rtx = lines.filter { it.startsWith("a=fmtp:") && it.contains("apt=") }.mapNotNull {
            val pt = it.substringAfter("a=fmtp:").substringBefore(" ")
            val apt = it.substringAfter("apt=").trim()
            if (apt in h264) pt else null
        }
        val parts = lines[mIdx].split(" ")
        val header = parts.take(3)
        val pts = parts.drop(3)
        val first = pts.filter { it in h264 || it in rtx }
        val rest = pts.filter { it !in first }
        lines[mIdx] = (header + first + rest).joinToString(" ")
        return lines.joinToString("\r\n")
    }

    private fun tune(p: PeerConnection) {
        try {
            val s = p.senders.firstOrNull { it.track()?.kind() == "video" } ?: return
            val params = s.parameters
            params.degradationPreference = RtpParameters.DegradationPreference.MAINTAIN_FRAMERATE
            for (e in params.encodings) {
                e.maxBitrateBps = Config.MAX_BITRATE
                e.minBitrateBps = 1_500_000
                e.maxFramerate = Config.FPS
            }
            s.setParameters(params)
        } catch (e: Exception) { }
    }

    private fun closePc() {
        try {
            pc?.close()
            pc?.dispose()
        } catch (e: Exception) { }
        pc = null
    }

    private fun shutdown() {
        if (!stopped.compareAndSet(false, true)) return
        Status.set("Parado", false)
        Thread {
            try {
                signaling?.send(JSONObject().put("from", "p").put("t", "bye"))
                signaling?.close()
            } catch (e: Exception) { }
            try { capturer?.stopCapture() } catch (e: Exception) { }
            try { capturer?.dispose() } catch (e: Exception) { }
            closePc()
            try { track?.dispose() } catch (e: Exception) { }
            try { source?.dispose() } catch (e: Exception) { }
            try { helper?.dispose() } catch (e: Exception) { }
            try { factory?.dispose() } catch (e: Exception) { }
            try { egl?.release() } catch (e: Exception) { }
            try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
            stopSelf()
        }.start()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
