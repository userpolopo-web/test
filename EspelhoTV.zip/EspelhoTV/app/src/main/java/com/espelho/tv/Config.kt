package com.espelho.tv

object Config {
    val STUN = listOf("stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302")

    // Opcional: servidor TURN (ajuda quando a rede bloqueia conexão direta). Ex.: "turn:meuservidor.com:3478"
    const val TURN_URL = ""
    const val TURN_USER = ""
    const val TURN_PASS = ""

    // Canal de pareamento (só troca o "aperto de mão"; o vídeo vai direto celular -> TV)
    const val NTFY = "https://ntfy.sh"

    const val FPS = 30
    const val MAX_LONG_SIDE = 1920
    const val MAX_BITRATE = 8_000_000
}
