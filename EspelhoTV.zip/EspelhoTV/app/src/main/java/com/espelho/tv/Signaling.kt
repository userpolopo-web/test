package com.espelho.tv

import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class Signaling(
    code: String,
    private val onOpen: () -> Unit,
    private val onMessage: (JSONObject) -> Unit,
) {
    private val base = Config.NTFY + "/pcmirror-" + code
    private val streamClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private val postClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
    private val sender = Executors.newSingleThreadExecutor()

    @Volatile private var closed = false
    @Volatile private var call: Call? = null
    private var lastId: String? = null
    private val seen = HashSet<String>()
    private val parts = HashMap<String, Array<String?>>()

    fun start() {
        val t = Thread {
            while (!closed) {
                try {
                    val since = lastId
                    val url = base + "/json" + (if (since != null) "?since=$since" else "")
                    val c = streamClient.newCall(Request.Builder().url(url).build())
                    call = c
                    c.execute().use { resp ->
                        if (!resp.isSuccessful) throw IOException("HTTP " + resp.code)
                        val src = resp.body!!.source()
                        while (!closed) {
                            val line = src.readUtf8Line() ?: break
                            handleLine(line)
                        }
                    }
                } catch (e: Exception) {
                    // tenta de novo
                }
                if (!closed) {
                    try { Thread.sleep(1000) } catch (e: InterruptedException) { }
                }
            }
        }
        t.isDaemon = true
        t.start()
    }

    private fun handleLine(line: String) {
        if (line.isBlank()) return
        val j = try { JSONObject(line) } catch (e: Exception) { return }
        when (j.optString("event")) {
            "open" -> onOpen()
            "message" -> {
                val id = j.optString("id")
                if (id.isNotEmpty()) {
                    if (!seen.add(id)) return
                    lastId = id
                }
                var obj = try { JSONObject(j.optString("message")) } catch (e: Exception) { return }
                if (obj.has("z")) {
                    val zid = obj.getString("z")
                    val n = obj.getInt("n")
                    val arr = parts.getOrPut(zid) { arrayOfNulls<String>(n) }
                    arr[obj.getInt("i")] = obj.getString("d")
                    if (arr.any { it == null }) return
                    parts.remove(zid)
                    obj = try { JSONObject(arr.joinToString("")) } catch (e: Exception) { return }
                }
                if (obj.optString("from") != "p") onMessage(obj)
            }
        }
    }

    fun send(obj: JSONObject) {
        val s = obj.toString()
        val size = 2800
        if (s.length <= size) {
            post(s)
        } else {
            val id = java.lang.Long.toString(System.nanoTime(), 36)
            val chunks = s.chunked(size)
            chunks.forEachIndexed { i, d ->
                post(JSONObject().put("z", id).put("i", i).put("n", chunks.size).put("d", d).toString())
            }
        }
    }

    private fun post(text: String) {
        try {
            sender.execute {
                try {
                    val req = Request.Builder().url(base)
                        .post(text.toRequestBody("text/plain".toMediaType())).build()
                    postClient.newCall(req).execute().close()
                } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
    }

    fun close() {
        closed = true
        call?.cancel()
        sender.shutdown()
    }
}
