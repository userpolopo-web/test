package com.espelho.tv

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var codeInput: EditText
    private lateinit var status: TextView
    private lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0B10")
        window.navigationBarColor = Color.parseColor("#0B0B10")
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#0B0B10"))
        root.setPadding(px(28), px(28), px(28), px(28))

        val title = TextView(this)
        title.text = "Espelho TV"
        title.textSize = 32f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER
        root.addView(title)

        val help = TextView(this)
        help.text = "1. Abra a página do Espelho TV no navegador da TV\n2. Digite aqui o código que aparece na TV\n3. Toque em COMEÇAR"
        help.textSize = 15f
        help.setTextColor(Color.parseColor("#9CA3AF"))
        help.setPadding(0, px(16), 0, px(24))
        root.addView(help)

        codeInput = EditText(this)
        codeInput.hint = "CÓDIGO DA TV"
        codeInput.textSize = 28f
        codeInput.gravity = Gravity.CENTER
        codeInput.setTextColor(Color.WHITE)
        codeInput.setHintTextColor(Color.parseColor("#4B5563"))
        codeInput.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        codeInput.filters = arrayOf(InputFilter.AllCaps(), InputFilter.LengthFilter(9))
        codeInput.setText(getSharedPreferences("p", 0).getString("code", ""))
        root.addView(
            codeInput,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        btn = Button(this)
        btn.textSize = 18f
        btn.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#3B82F6"))
        bg.cornerRadius = px(16).toFloat()
        btn.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(64))
        lp.topMargin = px(24)
        root.addView(btn, lp)

        status = TextView(this)
        status.textSize = 16f
        status.gravity = Gravity.CENTER
        status.setTextColor(Color.parseColor("#D1D5DB"))
        status.setPadding(0, px(20), 0, 0)
        root.addView(status)

        setContentView(root)

        btn.setOnClickListener {
            if (Status.running) {
                startService(Intent(this, MirrorService::class.java).setAction("stop"))
                return@setOnClickListener
            }
            val code = codeInput.text.toString().uppercase().filter { it.isLetterOrDigit() }
            if (code.length != 8) {
                status.text = "Digite o código de 8 letras/números que aparece na TV."
                return@setOnClickListener
            }
            getSharedPreferences("p", 0).edit().putString("code", code).apply()
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 42)
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun refresh() {
        status.text = if (Status.text.isEmpty()) "Pronto." else Status.text
        btn.text = if (Status.running) "PARAR" else "COMEÇAR A ESPELHAR"
    }

    override fun onResume() {
        super.onResume()
        Status.listener = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() {
        Status.listener = null
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42) {
            if (resultCode == RESULT_OK && data != null) {
                val code = getSharedPreferences("p", 0).getString("code", "") ?: ""
                val i = Intent(this, MirrorService::class.java)
                    .putExtra("code", code)
                    .putExtra("data", data)
                startForegroundService(i)
                Status.set("Iniciando…", true)
            } else {
                status.text = "Permissão de captura negada."
            }
        }
    }
}
